/**
 * @file   student.h
 * @author Author 
 * @brief  This is a library for updating and getting information about certai 
 * @date   2022-04-10
 */




/**
 * @brief The Student definition contains a first and last name as well as an id number, list of grades and total number of grrades
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< First name */
  char last_name[50];  /**< Last  name */
  char id[11];         /**< Id number  */
  double *grades;      /**< A list of grades */
  int num_grades;      /**< The total number of grades*/
} Student;


void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
