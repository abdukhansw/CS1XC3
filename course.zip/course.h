/**
 * @file   course.h
 * @author Author 
 * @brief  This is a library for updating and getting information about certain courses 
 * @date   2022-04-10
 */



#include "student.h"
#include <stdbool.h>
 

/**
 * @brief Course type that stores 
 *        course name, course code, a list 
 *        of students and total number of students 
 * 
 */
typedef struct _course 
{
  char name[100]; /**< The course name  */
  char code[10];  /**< The course code  */
  Student *students;  /**< A list of students  */
  int total_students; /**< Total number of students */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


