/**
 * @file   student.c
 * @author Author
 * @brief  This file defines functions for the 'Student' type 
 * @date   2022-04-10
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"


/**
 * @brief          This function will add a grade to the list of grades that a student has  
 * @param student  This is the student you want to add the grade to
 * @param grade    This is the grade you want to add
 * 
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); // This will initialize the grade list 
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades); 
      /* If the grade list is already intialized then it will simply increment the length 
         of the list so that one more grade can be fit in 
      */
  }
  /* This will add the grade at the end of the grades list */
  student->grades[student->num_grades - 1] = grade;
}


/**
 * @brief This function finds the average of grade of a student
 * 
 * @param student This is the student you want their avg 
 * @return double This is the avg that that sutdent has
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0; // If the grade list is not initialized then it will return 0

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades); 
}

/**
 * @brief This function  will print the students name, id, grades, and avg in a nicely fromatted way 
 * 
 * @param student  This is the student that you want to print
 * @returns        nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}


/**
 * @brief This function will generate a random student
 * 
 * @param grades     This is the number of grades you want the student to have
 * @return Student*  This will be a pointer pointing to a student
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"}; 
     // List of names that are to be randomly selected

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
     // List of names that are to be randomly selected
 
  Student *new_student = calloc(1, sizeof(Student)); // allocation of memory for one student

  strcpy(new_student->first_name, first_names[rand() % 24]); // creates first name  by randomly choosing from "first_names"
  strcpy(new_student->last_name, last_names[rand() % 24]);   // creates second name by randomly choosing from "last_names"

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48); // create an id from a list of numbers that are chars
  new_student->id[10] = '\0';  //put null terminating char at the end

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75))); // randomly put in grades in to new_student
  }

  return new_student;
}