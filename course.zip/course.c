/**
 * @file course.c
 * @brief This file defines useful functions for courses
 * @version 0.1
 * @date 2022-04-10
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief This function simply enrolls the students
 * @param Course  It takes in a course to add to 
 * @param Student It also takes a student to add
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++; 
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); // will allocate space for only one student
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
      /* It will allocate space when more than 1 students are in the course*/
  }
  course->students[course->total_students - 1] = *student; // will add the student to the list of students
}



/**
 * @brief This function will print the name, course code, total number of students and each student
 * 
 * @param course  The course you wanna print
 * 
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This function will find the student with the highest average in the course 
 * 
 * @param course The course you want to 
 * @return Student* A pointer pointing to the student that has the highest avg in the course 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}


/**
 * @brief This function will find which students are passing, and update the amount of "total_passing" that is provided in the second argument  
 * 
 * @param course        The course you want the pass     
 * @param total_passing This is the number of students that are previously thought to pass 
 * @return Student*     The list of students that are passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++; // count keeps track of the number of students that pass
  
  passing = calloc(count, sizeof(Student)); // This is a list that has enough room to fit everyone that passes 

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count; //updates the amount of total_passing

  return passing;
}